# Mathematical and Algorithmic Analysis of Bloom Filters

This document presents the complete mathematical derivation, hashing theory, and algorithmic complexity behind the **Memory-Limited Duplicate Event Detector**.

---

## 1. What is a Bloom Filter?

Invented by Burton Howard Bloom in 1970, a **Bloom Filter** is a space-efficient, probabilistic data structure designed to test set membership ($x \in S$).

A Bloom Filter offers two definite guarantees:
1. **Zero False Negatives**: If the filter reports `might_contain(x) == False`, item $x$ is **definitely not in the set** ($100\%$ certainty).
2. **Controlled False Positives**: If the filter reports `might_contain(x) == True`, item $x$ is **possibly in the set**, with a bounded probability $p$ that it is a false alarm.

---

## 2. Mathematical Foundation & Sizing Formulas

Let:
- $n$: Expected number of items to be inserted.
- $p$: Desired target false-positive probability ($0 < p < 1$).
- $m$: Optimal number of bits in the bit array.
- $k$: Optimal number of independent hash functions.

### 2.1 Calculating Optimal Bit Array Size ($m$)

The formula for the minimum number of bits $m$ required to achieve false positive rate $p$ given $n$ items is:

$$m = -\frac{n \cdot \ln(p)}{(\ln 2)^2}$$

Because $(\ln 2)^2 \approx 0.480453$, this simplifies in computation to:

$$m \approx -2.08136 \cdot n \cdot \ln(p)$$

**Example:** For $n = 10,000$ and $p = 0.01$ ($1\%$ error):
$$m = -\frac{10000 \cdot \ln(0.01)}{(0.693147)^2} = \frac{10000 \cdot 4.60517}{0.480453} \approx 95,851\text{ bits} \approx 11.7\text{ KB}$$

Storing $10,000$ strings in a traditional Python `set` or hash table requires $\approx 1.14\text{ MB}$. The Bloom filter achieves a **$98.9\%$ memory reduction**!

---

### 2.2 Calculating Optimal Number of Hash Functions ($k$)

To minimize the false-positive probability for a given $m$ and $n$, the optimal number of hash functions is:

$$k = \frac{m}{n} \cdot \ln(2)$$

Rounding to the nearest integer:
$$k = \text{round}\left( \frac{95,851}{10,000} \cdot 0.693147 \right) = \text{round}(6.6438) = 7\text{ hash functions}$$

---

### 2.3 Calculating Theoretical False-Positive Rate ($p$)

After $n$ items have been inserted using $k$ hash functions into a bit array of size $m$:

The probability that a specific bit is still $0$ after one hash computation is:
$$1 - \frac{1}{m}$$

After inserting $n$ items, each hashed $k$ times ($k \cdot n$ bit operations):
$$P(\text{bit is } 0) = \left(1 - \frac{1}{m}\right)^{k \cdot n} \approx e^{-\frac{k \cdot n}{m}}$$

Therefore, the probability that a bit is $1$ (fill ratio) is:
$$P(\text{bit is } 1) = 1 - e^{-\frac{k \cdot n}{m}}$$

A false positive occurs when querying an uninserted item and **all $k$** of its hash positions happen to hit bits that are already set to $1$:

$$p = \left( 1 - e^{-\frac{k \cdot n}{m}} \right)^k$$

---

## 3. Hash Function Engineering: Kirsch-Mitzenmacher Technique

Computing $k$ independent cryptographic hashes (such as running SHA-256 or MD5 seven separate times) is computationally expensive.

In our Python implementation, we utilize the mathematically proven **Kirsch-Mitzenmacher optimization** (Harvard University, 2006):

> *Two independent 64-bit hash values ($h_1$ and $h_2$) are sufficient to simulate $k$ independent hash functions without any asymptotic loss in false-positive performance.*

### The Formula:
$$g_i(x) = (h_1(x) + i \cdot h_2(x)) \pmod m \quad \text{for } i \in [0, k-1]$$

Where:
- $h_1(x)$ is computed via **64-bit FNV-1a** (Fowler–Noll–Vo prime hash).
- $h_2(x)$ is derived via **Murmur3 64-bit Avalanche bit mixing** combined with cryptographic SHA-256 seed dispersion.
- If $h_2(x) == 0$, it is remapped to `0x517cc1b727220a95` to ensure no degenerate cycles occur.

---

## 4. Algorithmic Complexity

| Operation | Time Complexity | Auxiliary Space | Explanation |
| :--- | :--- | :--- | :--- |
| **`add(event)`** | $\mathcal{O}(k)$ | $\mathcal{O}(1)$ | Computes $h_1, h_2$ and flips $k$ bits in the bit array. |
| **`might_contain(event)`** | $\mathcal{O}(k)$ | $\mathcal{O}(1)$ | Short-circuits: checks up to $k$ bit positions. Returns `False` on the first $0$ bit encountered. |
| **Bit Array Storage** | $\mathcal{O}(1)$ runtime | $\mathcal{O}(m)$ bits | Fixed memory footprint $\lceil m/8 \rceil$ bytes allocated upon initialization. |
| **Two-Tier Deduplication** | $\mathcal{O}(k)$ avg | $\mathcal{O}(m \text{ bits} + N \cdot \text{size})$ | Avoids DB queries for 100% of genuinely new events. |

Because $k$ is a small constant (typically $4 \le k \le 10$), both insertion and query operate in **true $\mathcal{O}(1)$ constant time** with nanosecond execution latency!

---

## 5. Mathematical Proof: Why False Negatives Are Impossible

**Theorem:** A standard Bloom Filter has a false negative rate of exactly $0$.

**Proof by Contradiction:**
1. Suppose an event $E$ was previously added via `add(E)`.
2. The `add()` procedure computed bit indices $B = \{g_0(E), g_1(E), \dots, g_{k-1}(E)\}$.
3. For every index $b \in B$, the bit at position $b$ was set to $1$.
4. Standard Bloom filter bits are **never cleared or reset to $0$** during subsequent additions.
5. When querying `might_contain(E)`, the algorithm checks the exact same indices $B$.
6. Because every bit in $B$ was set to $1$ and no bit was ever cleared, every checked bit remains $1$.
7. The algorithm returns `False` **only if** at least one bit in $B$ is $0$.
8. Since no checked bit is $0$, `might_contain(E)` cannot return `False`.
9. Therefore, a false negative is mathematically impossible. $\blacksquare$
