import time
from typing import Set, Tuple, Union
from src.core.bloom_filter import BloomFilter
from src.model.detection_result import DetectionResult, DetectionStatus
from src.model.event import Event


class TwoTierDetector:
    """Two-Tier Event Deduplication Engine.
    
    Architecture:
      [Incoming Event]
             |
             v
      Tier 1: Bloom Filter (L1 Probabilistic Screener - O(k) time, nano-second latency)
             |
             +---> might_contain() == False: DEFINITELY UNIQUE!
             |     - Add to Bloom Filter
             |     - Add to Exact Storage
             |     - Result: DEFINITE_UNIQUE (Database / Tier 2 lookup completely avoided!)
             |
             +---> might_contain() == True: CANDIDATE DUPLICATE (Possible match or False Positive)
                   |
                   v
            Tier 2: Exact Storage / DB Lookup (L2 Exact Verification)
                   |
                   +---> Exists in Storage: CONFIRMED_DUPLICATE
                   |
                   +---> Not in Storage: FALSE_POSITIVE_RESOLVED!
                         - Insert into Storage
                         - Result: FALSE_POSITIVE_RESOLVED
    """

    def __init__(self, bloom_filter: BloomFilter = None):
        self.bloom_filter = bloom_filter if bloom_filter is not None else BloomFilter()
        self.exact_storage: Set[str] = set()

        # Operational telemetry
        self.total_processed: int = 0
        self.confirmed_duplicates: int = 0
        self.db_lookups_avoided: int = 0
        self.db_lookups_performed: int = 0
        self.false_positives_intercepted: int = 0

    def process_event(self, event: Union[str, Event]) -> DetectionResult:
        """Processes an incoming event through the two-tier deduplication pipeline.
        
        :param event: String payload or Event object
        :return: DetectionResult detailing status, latency, and Tier 1 / Tier 2 actions.
        """
        start_ns = time.perf_counter_ns()
        evt = event if isinstance(event, Event) else Event(payload=str(event).strip())
        payload = evt.get_identity_string()

        if not payload:
            raise ValueError("Event cannot be empty.")

        self.total_processed += 1
        positions = self.bloom_filter.get_bit_positions(payload)

        # Tier 1: Check Bloom Filter
        might_exist = self.bloom_filter.might_contain(payload)

        if not might_exist:
            # 100% Guaranteed NEW EVENT!
            # Zero chance of false negative: No need to query Tier 2 database.
            self.db_lookups_avoided += 1
            self.bloom_filter.add(payload)
            self.exact_storage.add(payload)
            latency_us = (time.perf_counter_ns() - start_ns) / 1000.0

            return DetectionResult(
                event=evt,
                status=DetectionStatus.DEFINITE_UNIQUE,
                bit_positions=positions,
                latency_micros=latency_us,
                message="Tier 1 Bloom Filter returned ABSENT. Event is guaranteed fresh. DB query saved!"
            )

        # Tier 1 returned True -> Might be duplicate or False Positive
        self.db_lookups_performed += 1
        is_exact_match = payload in self.exact_storage

        if is_exact_match:
            # Tier 2 Confirmed Duplicate
            self.confirmed_duplicates += 1
            latency_us = (time.perf_counter_ns() - start_ns) / 1000.0

            return DetectionResult(
                event=evt,
                status=DetectionStatus.CONFIRMED_DUPLICATE,
                bit_positions=positions,
                latency_micros=latency_us,
                message="Tier 1 Bloom Filter flagged match -> Tier 2 Exact Storage confirmed DUPLICATE."
            )
        else:
            # Tier 1 was a False Positive! Tier 2 saved us from mistakenly dropping a new event!
            self.false_positives_intercepted += 1
            self.exact_storage.add(payload)
            latency_us = (time.perf_counter_ns() - start_ns) / 1000.0

            return DetectionResult(
                event=evt,
                status=DetectionStatus.FALSE_POSITIVE_RESOLVED,
                bit_positions=positions,
                latency_micros=latency_us,
                message="Tier 1 Bloom Filter gave FALSE POSITIVE! Tier 2 resolved it as a fresh event."
            )

    def get_db_avoidance_rate(self) -> float:
        """Returns the percentage of database queries avoided by the Bloom Filter."""
        if self.total_processed == 0:
            return 100.0
        return (self.db_lookups_avoided / self.total_processed) * 100.0

    def get_stats_summary(self) -> str:
        """Formats performance statistics for terminal presentation."""
        return (
            f"--- Two-Tier Engine Telemetry ---\n"
            f"Total Events Processed:        {self.total_processed:,}\n"
            f"Confirmed Duplicates:          {self.confirmed_duplicates:,}\n"
            f"Fresh Events Registered:       {len(self.exact_storage):,}\n"
            f"DB Queries Avoided by Tier 1:  {self.db_lookups_avoided:,} ({self.get_db_avoidance_rate():.2f}%)\n"
            f"DB Queries Performed (Hits):   {self.db_lookups_performed:,}\n"
            f"False Positives Intercepted:   {self.false_positives_intercepted:,}\n"
            f"Tier 1 Bit Array Size (m):     {self.bloom_filter.size_in_bits:,} bits ({self.bloom_filter.get_memory_usage_bytes()} B)\n"
            f"Tier 1 Fill Ratio:             {self.bloom_filter.get_fill_ratio() * 100.0:.2f}%"
        )

