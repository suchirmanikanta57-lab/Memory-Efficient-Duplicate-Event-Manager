@echo off
TITLE Memory-Limited Duplicate Event Detector (Bloom Filter)
COLOR 0A
cls
echo =========================================================================
echo  Launching Memory-Limited Duplicate Event Detector (Pure Python 3)
echo =========================================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not found in your PATH.
    echo Please ensure Python 3.8+ is installed from https://python.org
    pause
    exit /b 1
)

python main.py
if %errorlevel% neq 0 (
    echo.
    echo [!] Program exited with code %errorlevel%.
)

pause
