"""Bloom Filter Duplicate Event Detector Package."""
__version__ = "1.0.0"
