import math
from typing import List, Union
from src.hash.hash_strategy import HashStrategy
from src.model.event import Event


class BloomFilter:
    """Space-efficient, probabilistic Bloom Filter implementation in pure Python.

    Guarantees:
    - might_contain() is False: GUARANTEED ABSENT (Zero False Negatives).
    - might_contain() is True:  POSSIBLY PRESENT (Controlled False Positives).
    """

    def __init__(self, expected_elements: int = None, target_fp_rate: float = None,
                 size_in_bits: int = None, hash_count: int = None):
        """Initializes a Bloom Filter.

        Can be initialized either with:
        1. (expected_elements, target_fp_rate) -> Calculates optimal m and k
        2. (size_in_bits, hash_count)          -> Uses explicit m and k
        """
        if expected_elements is not None and target_fp_rate is not None:
            if expected_elements <= 0:
                raise ValueError("Expected elements (n) must be strictly positive.")
            if not (0.0 < target_fp_rate < 1.0):
                raise ValueError("Target false-positive rate (p) must be in range (0.0, 1.0).")

            self.size_in_bits = self.calculate_optimal_m(expected_elements, target_fp_rate)
            self.hash_count = self.calculate_optimal_k(self.size_in_bits, expected_elements)
        elif size_in_bits is not None and hash_count is not None:
            if size_in_bits <= 0 or hash_count <= 0:
                raise ValueError("Bit array size (m) and hash count (k) must be strictly positive.")
            self.size_in_bits = size_in_bits
            self.hash_count = hash_count
        else:
            # Default sizing: 10,000 items, 1.0% error rate
            self.size_in_bits = self.calculate_optimal_m(10000, 0.01)
            self.hash_count = self.calculate_optimal_k(self.size_in_bits, 10000)

        # Bytearray storage: each byte stores 8 bits
        self._byte_count = (self.size_in_bits + 7) // 8
        self._bit_array = bytearray(self._byte_count)
        self.inserted_count = 0
        self._bits_set_count = 0

    def add(self, event: Union[str, Event]) -> bool:
        """Inserts an event into the Bloom Filter.

        :param event: String payload or Event object
        :return: True if at least one bit was newly flipped to 1; False if all bits were already 1.
        """
        payload = event.get_identity_string() if isinstance(event, Event) else str(event)
        if not payload or not payload.strip():
            raise ValueError("Event cannot be null or empty.")

        positions = HashStrategy.get_bit_positions(payload.strip(), self.size_in_bits, self.hash_count)
        changed = False

        for pos in positions:
            byte_idx = pos >> 3
            bit_mask = 1 << (pos & 7)

            if not (self._bit_array[byte_idx] & bit_mask):
                self._bit_array[byte_idx] |= bit_mask
                self._bits_set_count += 1
                changed = True

        self.inserted_count += 1
        return changed

    def might_contain(self, event: Union[str, Event]) -> bool:
        """Queries whether an event may have been recorded before.

        :param event: String payload or Event object
        :return: False if event is DEFINITELY ABSENT (100% guarantee);
                 True if event is POSSIBLY PRESENT (potential duplicate or false positive).
        """
        if event is None:
            return False

        payload = event.get_identity_string() if isinstance(event, Event) else str(event)
        if not payload or not payload.strip():
            return False

        positions = HashStrategy.get_bit_positions(payload.strip(), self.size_in_bits, self.hash_count)

        for pos in positions:
            byte_idx = pos >> 3
            bit_mask = 1 << (pos & 7)

            # Short-circuit: As soon as any single bit is 0, item was NEVER inserted!
            if not (self._bit_array[byte_idx] & bit_mask):
                return False

        # All k bits are 1 -> item might be present
        return True

    def get_bit_positions(self, event: Union[str, Event]) -> List[int]:
        """Returns the k calculated bit indices for an event."""
        payload = event.get_identity_string() if isinstance(event, Event) else str(event)
        return HashStrategy.get_bit_positions(payload.strip(), self.size_in_bits, self.hash_count)

    # =========================================================================
    # Mathematical Parameter Calculators & Telemetry
    # =========================================================================

    @staticmethod
    def calculate_optimal_m(n: int, p: float) -> int:
        """Formula: m = - (n * ln(p)) / (ln(2))^2"""
        m = - (n * math.log(p)) / (math.log(2.0) ** 2)
        return math.ceil(m)

    @staticmethod
    def calculate_optimal_k(m: int, n: int) -> int:
        """Formula: k = (m / n) * ln(2)"""
        k = (m / n) * math.log(2.0)
        return max(1, round(k))

    def get_theoretical_fp_rate(self) -> float:
        """Calculates expected theoretical false-positive probability:

        p = (1 - e^(-k * n / m))^k
        """
        if self.inserted_count == 0:
            return 0.0
        exponent = - (self.hash_count * self.inserted_count) / self.size_in_bits
        base = 1.0 - math.exp(exponent)
        return base ** self.hash_count

    def get_fill_ratio(self) -> float:
        """Returns the fraction of bits currently set to 1."""
        return self._bits_set_count / self.size_in_bits

    def get_bits_set_count(self) -> int:
        """Returns total bits set to 1."""
        return self._bits_set_count

    def get_memory_usage_bytes(self) -> int:
        """Returns RAM used by the bit storage bytearray in bytes."""
        return self._byte_count + 56  # includes Python object header overhead

    def clear(self) -> None:
        """Resets all bits to 0 and clears counters."""
        self._bit_array = bytearray(self._byte_count)
        self.inserted_count = 0
        self._bits_set_count = 0

    def get_stats_summary(self) -> str:
        """Formats comprehensive statistics for terminal display."""
        mem_bytes = self.get_memory_usage_bytes()
        mem_kb = mem_bytes / 1024.0
        fill_pct = self.get_fill_ratio() * 100.0
        fp_pct = self.get_theoretical_fp_rate() * 100.0
        bits_per_element = (self.size_in_bits / self.inserted_count) if self.inserted_count > 0 else 0.0

        return (
            f"--- Bloom Filter Telemetry & Statistics ---\n"
            f"Inserted Elements (n):       {self.inserted_count:,}\n"
            f"Bit Array Size (m):          {self.size_in_bits:,} bits\n"
            f"Hash Functions (k):          {self.hash_count}\n"
            f"Memory Footprint:            {mem_bytes:,} bytes ({mem_kb:.2f} KB)\n"
            f"Bits Set to 1:               {self._bits_set_count:,} / {self.size_in_bits:,}\n"
            f"Bit Array Fill Ratio:        {fill_pct:.2f}%\n"
            f"Theoretical False Positive:  {fp_pct:.4f}%\n"
            f"Bits per Inserted Element:   {bits_per_element:.2f} bits/item"
        )

    def __repr__(self) -> str:
        return (f"BloomFilter[m={self.size_in_bits} bits ({self.get_memory_usage_bytes() / 1024:.2f} KB), "
                f"k={self.hash_count}, items={self.inserted_count}, "
                f"fill={self.get_fill_ratio() * 100:.2f}%, theoryFP={self.get_theoretical_fp_rate() * 100:.4f}%]")
